G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*
G04 #@! TF.CreationDate,2026-06-01T23:57:36-05:00*
G04 #@! TF.ProjectId,mezzanine-0p5x1,6d657a7a-616e-4696-9e65-2d3070357831,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-06-01 23:57:36*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,0.100000*%
%ADD11RoundRect,0.020000X0.980000X2.580000X-0.980000X2.580000X-0.980000X-2.580000X0.980000X-2.580000X0*%
G04 APERTURE END LIST*
G04 #@! TO.C,U1*
D10*
X153000000Y-85000000D02*
X161000000Y-85000000D01*
X161000000Y-95000000D01*
X153000000Y-95000000D01*
X153000000Y-85000000D01*
G36*
X153000000Y-85000000D02*
G01*
X161000000Y-85000000D01*
X161000000Y-95000000D01*
X153000000Y-95000000D01*
X153000000Y-85000000D01*
G37*
G04 #@! TD*
D11*
G04 #@! TO.C,U1*
X157000000Y-90000000D03*
G04 #@! TD*
M02*
